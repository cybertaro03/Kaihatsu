'use strict';

/**
 * ストレージ層。
 *
 *  - DB_SECRET_ID あり -> PostgreSQL。接続用のユーザー名/パスワードは起動時に
 *                         AWS Secrets Manager から取得する（lib/db-secret.js）。.env からは読まない。
 *  - DB_SECRET_ID なし -> data/store.json へのファイル保存（ローカル開発用）。
 *
 * 旧版は DB に繋がらないと黙ってファイル保存へ切り替えていたが、
 * データが DB とファイルに分裂するため廃止した。起動を止めて理由をログに出す。
 */

const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const { resolveStorageConfig } = require('./lib/db-config');
const { DbSecretProvider } = require('./lib/db-secret');
const { PgClient } = require('./lib/pg-client');

const DEFAULT_DATA_FILE = path.join(__dirname, 'data', 'store.json');
const BCRYPT_ROUNDS = 12;

const EMPTY_STATE = () => ({
  vision: { company: '', target: '', details: '' },
  items: [],
  globalMinutes: []
});

class StoreInitError extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = 'StoreInitError';
  }
}

class Store {
  /**
   * @param {object} [opts]
   * @param {object} [opts.storageConfig]   resolveStorageConfig(process.env) の代わりに使う設定
   * @param {object} [opts.secretProvider]  DbSecretProvider の差し替え（テスト用）
   * @param {Function} [opts.createPool]    pg Pool 生成関数の差し替え（テスト用）
   * @param {string} [opts.dataFile]        ファイル保存モードの保存先
   * @param {number} [opts.oldPoolGraceMs]  再接続時に古いプールを閉じるまでの猶予
   * @param {object} [opts.logger]
   */
  constructor(opts = {}) {
    this.opts = opts;
    this.logger = opts.logger || console;
    this.dataFile = opts.dataFile || DEFAULT_DATA_FILE;
    this.mode = 'file';      // 'postgres' | 'file'
    this.db = null;
    this.cache = EMPTY_STATE();
    this.users = [];         // file モード時のみ使用
    this.writeQueue = Promise.resolve();
  }

  get connected() {
    return this.mode === 'postgres';
  }

  // ---------- 初期化 ----------

  async init() {
    const config = this.opts.storageConfig || resolveStorageConfig(process.env);

    if (config.mode !== 'postgres') {
      this.logger.warn(`[store] DB_SECRET_ID が未設定のため、ファイル保存（開発用）で起動します: ${this.dataFile}`);
      await this.loadFile();
      return;
    }

    const secretProvider = this.opts.secretProvider ||
      new DbSecretProvider({ secretId: config.secretId, region: config.region });

    const db = new PgClient({
      secretProvider,
      config,
      createPool: this.opts.createPool,
      logger: this.logger,
      oldPoolGraceMs: this.opts.oldPoolGraceMs
    });

    try {
      await db.init();
    } catch (err) {
      if (err.name === 'DbSecretError' || err.name === 'DbConfigError') throw err;
      // cause（pg のエラー）には DB ユーザー名・接続先が入る。出力するのは message だけにすること
      throw new StoreInitError(
        `PostgreSQL に接続できません [${err.code || err.name}]（認証情報: ${secretProvider.describe()}）。` +
        'PostgreSQL の起動状態・ホスト/ポート・pg_hba.conf・シークレットの内容を確認してください',
        { cause: err }
      );
    }

    this.db = db;
    if (!config.ssl && !isLoopbackHost(db.host) && process.env.NODE_ENV === 'production') {
      this.logger.warn(`[config] DB_SSL=true ではありません。別ホストの DB (${db.host}) との通信が暗号化されません。`);
    }
    if (config.autoSchema) await this.ensureSchema();
    this.mode = 'postgres';
    this.logger.log(`[store] PostgreSQL に接続しました (${db.target}) [認証情報: ${secretProvider.describe()}]`);
    await this.loadFromDb();
  }

  async ensureSchema() {
    const schema = await fsp.readFile(path.join(__dirname, 'db', 'schema.sql'), 'utf8');
    // ファイル全体を1回のクエリで流す（パラメータ無しの単純クエリは、複数の文を1トランザクションで実行する）。
    // 既存のテーブル・インデックスは IF NOT EXISTS でスキップされる。
    await this.db.query(schema);
  }

  // ---------- ファイルモード ----------

  async loadFile() {
    try {
      const raw = await fsp.readFile(this.dataFile, 'utf8');
      const parsed = JSON.parse(raw);
      this.cache = Object.assign(EMPTY_STATE(), {
        vision: parsed.vision || EMPTY_STATE().vision,
        items: Array.isArray(parsed.items) ? parsed.items : [],
        globalMinutes: Array.isArray(parsed.globalMinutes) ? parsed.globalMinutes : []
      });
      this.users = Array.isArray(parsed.users) ? parsed.users : [];
    } catch (err) {
      if (err.code !== 'ENOENT') {
        // 壊れたファイルを空データで上書きしてしまわないよう、起動を止める
        // JSON.parse のメッセージには内容の断片（パスワードハッシュ等）が含まれうるため出さない
        const reason = err instanceof SyntaxError ? 'JSON として解析できません' : (err.code || err.name);
        throw new StoreInitError(`${this.dataFile} を読み込めません: ${reason}`);
      }
      this.cache = EMPTY_STATE();
      this.users = [];
    }
  }

  // 直列化して書き込む（同時書き込みによる破損を防ぐ）
  persistFile() {
    const run = this.writeQueue.then(async () => {
      const payload = JSON.stringify({
        vision: this.cache.vision,
        items: this.cache.items,
        globalMinutes: this.cache.globalMinutes,
        users: this.users
      }, null, 2);

      await fsp.mkdir(path.dirname(this.dataFile), { recursive: true });
      const tmp = this.dataFile + '.tmp';
      // パスワードハッシュを含むため所有者のみ読み書き可にする
      await fsp.writeFile(tmp, payload, { encoding: 'utf8', mode: 0o600 });
      await fsp.rename(tmp, this.dataFile);   // 原子的に差し替える
    });
    // 失敗しても後続の書き込みは続けられるようにしつつ、呼び出し元には失敗を返す
    this.writeQueue = run.catch(() => {});
    return run;
  }

  // ---------- PostgreSQL モード ----------

  async loadFromDb() {
    const state = EMPTY_STATE();

    const { rows: visionRows } = await this.db.query('SELECT company, target, details FROM vision WHERE id = 1');
    if (visionRows.length) state.vision = {
      company: visionRows[0].company || '',
      target: visionRows[0].target || '',
      details: visionRows[0].details || ''
    };

    const { rows: itemRows } = await this.db.query('SELECT payload FROM items ORDER BY seq ASC');
    state.items = itemRows.map(r => parseJson(r.payload)).filter(Boolean);

    const { rows: minuteRows } = await this.db.query('SELECT payload FROM minutes ORDER BY seq ASC');
    state.globalMinutes = minuteRows.map(r => parseJson(r.payload)).filter(Boolean);

    this.cache = state;
  }

  // ---------- 公開 API（データ） ----------
  // メモリ上のキャッシュは DB 書き込みが成功してから更新する。
  // （旧版は先にキャッシュを書き換えていたため、DB 書き込み失敗時も他の利用者には保存済みに見えていた）

  getState() {
    return this.cache;
  }

  async saveVision(vision) {
    const next = pickVision(vision);

    if (this.mode === 'postgres') {
      await this.db.query(UPSERT_VISION_SQL, visionParams(next));
      this.cache.vision = next;
    } else {
      this.cache.vision = next;
      await this.persistFile();
    }
    return this.cache.vision;
  }

  async saveItem(input) {
    if (!input || !input.id) throw new Error('item.id が必要です');

    if (this.mode === 'postgres') {
      const { value: item, json } = toDbJson(input);
      await this.db.query(
        `INSERT INTO items (id, type, status, title, payload) VALUES ($1, $2, $3, $4, $5::jsonb)
         ON CONFLICT (id) DO UPDATE SET type = EXCLUDED.type, status = EXCLUDED.status,
                                        title = EXCLUDED.title, payload = EXCLUDED.payload, updated_at = now()`,
        itemParams(item, json)
      );
      upsertById(this.cache.items, item);
      return item;
    }
    upsertById(this.cache.items, input);
    await this.persistFile();
    return input;
  }

  async deleteItem(itemId) {
    if (this.mode === 'postgres') await this.db.query('DELETE FROM items WHERE id = $1', [stripNul(String(itemId))]);
    this.cache.items = this.cache.items.filter(i => i.id !== itemId);
    if (this.mode !== 'postgres') await this.persistFile();
  }

  async saveMinute(input) {
    if (!input || !input.id) throw new Error('minute.id が必要です');

    if (this.mode === 'postgres') {
      const { value: minute, json } = toDbJson(input);
      await this.db.query(
        `INSERT INTO minutes (id, title, meeting_date, related_item_id, payload) VALUES ($1, $2, $3, $4, $5::jsonb)
         ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, meeting_date = EXCLUDED.meeting_date,
                                        related_item_id = EXCLUDED.related_item_id, payload = EXCLUDED.payload,
                                        updated_at = now()`,
        minuteParams(minute, json)
      );
      upsertById(this.cache.globalMinutes, minute);
      return minute;
    }
    upsertById(this.cache.globalMinutes, input);
    await this.persistFile();
    return input;
  }

  async deleteMinute(minuteId) {
    if (this.mode === 'postgres') await this.db.query('DELETE FROM minutes WHERE id = $1', [stripNul(String(minuteId))]);
    this.cache.globalMinutes = this.cache.globalMinutes.filter(m => m.id !== minuteId);
    if (this.mode !== 'postgres') await this.persistFile();
  }

  /** 全体保存 / CSV 復元用：全データを置き換える */
  async replaceAll(data) {
    const next = {
      vision: pickVision(data?.vision),
      items: Array.isArray(data?.items) ? data.items.filter(i => i && i.id) : [],
      globalMinutes: Array.isArray(data?.globalMinutes) ? data.globalMinutes.filter(m => m && m.id) : []
    };

    if (this.mode === 'postgres') {
      const items = next.items.map(toDbJson);
      const minutes = next.globalMinutes.map(toDbJson);
      await this.db.transaction(async (conn) => {
        await conn.query('DELETE FROM items');
        await conn.query('DELETE FROM minutes');
        await conn.query(UPSERT_VISION_SQL, visionParams(next.vision));
        for (const { value, json } of items) {
          await conn.query(
            'INSERT INTO items (id, type, status, title, payload) VALUES ($1, $2, $3, $4, $5::jsonb)',
            itemParams(value, json)
          );
        }
        for (const { value, json } of minutes) {
          await conn.query(
            'INSERT INTO minutes (id, title, meeting_date, related_item_id, payload) VALUES ($1, $2, $3, $4, $5::jsonb)',
            minuteParams(value, json)
          );
        }
      });
      this.cache = {
        vision: next.vision,
        items: items.map(x => x.value),
        globalMinutes: minutes.map(x => x.value)
      };
    } else {
      this.cache = next;
      await this.persistFile();
    }
    return this.cache;
  }

  // ---------- 公開 API（ユーザー） ----------

  async countUsers() {
    if (this.mode === 'postgres') {
      // COUNT(*) は bigint のため pg は文字列で返す
      const { rows } = await this.db.query('SELECT COUNT(*) AS n FROM users');
      return Number(rows[0].n);
    }
    return this.users.length;
  }

  async listUsers() {
    if (this.mode === 'postgres') {
      const { rows } = await this.db.query(
        'SELECT id, username, email, role FROM users ORDER BY created_at ASC, id ASC'
      );
      return rows;
    }
    return this.users.map(u => ({ id: u.id, username: u.username, email: u.email, role: u.role }));
  }

  async findUserByUsername(username) {
    if (this.mode === 'postgres') {
      // PostgreSQL の文字列は NUL (U+0000) を含められず、パラメータに渡すとエラーになる。
      // そのような名前のユーザーは存在しえないので、DB に問い合わせず「該当なし」とする
      if (typeof username !== 'string' || username.includes('\u0000')) return null;
      const { rows } = await this.db.query(
        'SELECT id, username, email, role, password_hash FROM users WHERE username = $1 LIMIT 1',
        [username]
      );
      return rows[0] || null;
    }
    return this.users.find(u => u.username === username) || null;
  }

  async createUser({ username, email, password, role = 'admin' }) {
    const passwordHash = await hashPassword(password);

    if (this.mode === 'postgres') {
      const { rows } = await this.db.query(
        `INSERT INTO users (username, email, password_hash, role) VALUES ($1, $2, $3, $4)
         RETURNING id, username, email, role, password_hash`,
        [username, email, passwordHash, role]
      );
      return rows[0] || null;
    }

    if (this.users.some(u => u.username === username)) {
      throw new Error(`ユーザー ${username} は既に存在します`);
    }
    const user = {
      id: crypto.randomUUID(),
      username,
      email,
      password_hash: passwordHash,
      role,
      created_at: new Date().toISOString()
    };
    this.users.push(user);
    await this.persistFile();
    return user;
  }

  async updatePassword(userId, password) {
    const passwordHash = await hashPassword(password);

    if (this.mode === 'postgres') {
      await this.db.query('UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2', [passwordHash, userId]);
      return;
    }
    const user = this.users.find(u => u.id === userId);
    if (user) {
      user.password_hash = passwordHash;
      await this.persistFile();
    }
  }

  async deleteUser(userId) {
    if (this.mode === 'postgres') {
      await this.db.query('DELETE FROM users WHERE id = $1', [userId]);
      return;
    }
    this.users = this.users.filter(u => u.id !== userId);
    await this.persistFile();
  }

  async verifyPassword(user, password) {
    return verifyPasswordHash(password, user && user.password_hash);
  }

  async close() {
    await this.writeQueue;
    if (this.db) await this.db.end();
  }
}

// ---------- パスワードのハッシュ化 ----------

// bcrypt は先頭 72 バイトしか見ないため、それより長いと黙って切り捨てられる
const PASSWORD_MIN_LENGTH = 8;
const PASSWORD_MAX_BYTES = 72;

function validateNewPassword(password) {
  if (typeof password !== 'string' || password.length < PASSWORD_MIN_LENGTH) {
    return `パスワードは${PASSWORD_MIN_LENGTH}文字以上にしてください`;
  }
  if (Buffer.byteLength(password, 'utf8') > PASSWORD_MAX_BYTES) {
    return `パスワードは${PASSWORD_MAX_BYTES}バイト以内にしてください（全角は1文字3バイト）`;
  }
  return null;
}

async function hashPassword(password) {
  const problem = validateNewPassword(password);
  if (problem) throw new Error(problem);
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

// 存在しないユーザーでも同じだけ bcrypt の計算をさせ、
// 応答時間の差からユーザー名の有無を推測されないようにするためのダミー
const DUMMY_HASH = bcrypt.hashSync(crypto.randomBytes(16).toString('hex'), BCRYPT_ROUNDS);

async function verifyPasswordHash(password, hash) {
  if (typeof password !== 'string' || password.length === 0) return false;
  if (typeof hash !== 'string' || hash.length === 0) {
    await bcrypt.compare(password, DUMMY_HASH);
    return false;
  }
  return bcrypt.compare(password, hash);
}

// ---------- ヘルパー ----------

function upsertById(list, entry) {
  const idx = list.findIndex(x => x.id === entry.id);
  if (idx >= 0) list[idx] = entry;
  else list.push(entry);
}

function pickVision(v) {
  const src = v && typeof v === 'object' ? v : {};
  return {
    company: stripNul(String(src.company || '')),
    target: stripNul(String(src.target || '')),
    details: stripNul(String(src.details || ''))
  };
}

function parseJson(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;   // pg は JSONB 列をオブジェクトで返す
  try { return JSON.parse(value); } catch (e) { return null; }
}

function isLoopbackHost(host) {
  return ['localhost', '127.0.0.1', '::1'].includes(String(host || '').toLowerCase()) ||
    String(host || '').startsWith('/');   // Unix ドメインソケット
}

// 'YYYY-MM-DDTHH:mm' (datetime-local) をサーバーのタイムゾーンで解釈し、
// TIMESTAMPTZ 用の ISO 8601 文字列（UTC）にする
function toPgTimestamp(value) {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}

const UPSERT_VISION_SQL =
  `INSERT INTO vision (id, company, target, details) VALUES (1, $1, $2, $3)
   ON CONFLICT (id) DO UPDATE SET company = EXCLUDED.company, target = EXCLUDED.target,
                                  details = EXCLUDED.details, updated_at = now()`;

// PostgreSQL の text 列も NUL (U+0000) を保存できない
function stripNul(s) {
  return s.includes('\u0000') ? s.replace(/\u0000/g, '') : s;
}

function visionParams(v) {
  return [v.company, v.target, v.details];   // pickVision() で NUL 除去済み
}

// 列に取り出す値は、NUL 除去済みの値（toDbJson の value）から作ること
function itemParams(item, json) {
  return [String(item.id), String(item.type || ''), String(item.status || 'active'), String(item.title || ''), json];
}

function minuteParams(m, json) {
  return [String(m.id), String(m.title || ''), toPgTimestamp(m.date), m.relatedWGId ? String(m.relatedWGId) : null, json];
}

/**
 * JSONB 列に渡す JSON 文字列を作る。
 * PostgreSQL の JSONB / text は NUL (U+0000) を保存できず、含まれていると書き込み全体がエラーになる
 * （MySQL では保存できていた）。NUL は画面上の意味を持たないため取り除き、
 * DB の内容とメモリ上のキャッシュが一致するよう、取り除いた後の値も返す。
 */
function toDbJson(value) {
  const json = JSON.stringify(value);
  if (!json.includes('\\u0000')) return { value, json };
  const cleaned = JSON.stringify(value, (key, v) => (typeof v === 'string' ? stripNul(v) : v));
  return { value: JSON.parse(cleaned), json: cleaned };
}

module.exports = {
  Store,
  StoreInitError,
  EMPTY_STATE,
  hashPassword,
  verifyPasswordHash,
  validateNewPassword,
  BCRYPT_ROUNDS
};
