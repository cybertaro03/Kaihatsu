'use strict';

// /api/login over real HTTP (127.0.0.1, ephemeral port). Secrets Manager is mocked.

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const express = require('express');

const { createLoginHandler, LoginLimiter } = require('../lib/login-route');
const { Authenticator } = require('../lib/authenticator');
const { UsersSecretProvider } = require('../lib/users-secret');
const { makeHash, usersJson, mockClient, awsError, fakeClock, silentLogger } = require('../test-support/helpers');

const PASS_A = 'alice-test-pass';
const HASH_A = makeHash(PASS_A);

async function startServer(t, { responses, store = null, usersProvider } = {}) {
  const clock = fakeClock();
  const client = mockClient(responses || [usersJson({ alice: { passwordHash: HASH_A } })]);
  const provider = usersProvider !== undefined
    ? usersProvider
    : new UsersSecretProvider({ secretId: 'test/users', region: 'ap-northeast-1', client, now: clock.now });
  const logger = silentLogger();
  const authenticator = new Authenticator({ store, usersProvider: provider, logger });
  const app = express();
  app.use(express.json());
  app.post('/api/login', createLoginHandler({ authenticator, limiter: new LoginLimiter(), logger }));
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const url = `http://127.0.0.1:${server.address().port}/api/login`;
  const login = async (body) => {
    const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    return { status: res.status, body: await res.json() };
  };
  return { login, client, logger, clock };
}

test('HTTP: 正常ログインは success:true とユーザー名のみ返す（ハッシュ等は返さない）', async (t) => {
  const { login } = await startServer(t);
  const res = await login({ username: 'alice', password: PASS_A });
  assert.equal(res.status, 200);
  assert.deepEqual(res.body, { success: true, username: 'alice' });
});

test('HTTP: 誤パスワードと未知ユーザーは同じ応答（ユーザー列挙防止）', async (t) => {
  const { login } = await startServer(t);
  const wrong = await login({ username: 'alice', password: 'wrong-password' });
  const unknown = await login({ username: 'nobody', password: 'wrong-password' });
  assert.equal(wrong.status, 200);
  assert.deepEqual(wrong, unknown);
  assert.equal(wrong.body.success, false);
});

test('HTTP: 入力が空なら照合しない', async (t) => {
  const { login, client } = await startServer(t);
  const res = await login({ username: '  ', password: '' });
  assert.equal(res.body.success, false);
  assert.match(res.body.error, /入力してください/);
  assert.equal(client.calls.length, 0);
});

test('HTTP: シークレット取得失敗は 503 でログイン拒否（フェイルクローズ）、応答に内部情報を出さない', async (t) => {
  const marker = 'HttpSecretMarker_77';
  const { login, logger } = await startServer(t, { responses: [awsError('AccessDeniedException', marker)] });
  const res = await login({ username: 'alice', password: PASS_A });
  assert.equal(res.status, 503);
  assert.equal(res.body.success, false);
  const text = JSON.stringify(res.body);
  assert.ok(!/test\/users|AccessDenied|Secrets Manager/.test(text), '応答にシークレット名や AWS エラーを出さない');
  assert.ok(!logger.lines.join('\n').includes(marker), 'ログにも SDK のメッセージを出さない');
  assert.ok(logger.lines.some((l) => /ログインを拒否/.test(l)));
});

test('HTTP: 503 はロックアウトの失敗回数に数えない', async (t) => {
  const { login } = await startServer(t, { responses: [awsError('AccessDeniedException')] });
  for (let i = 0; i < 6; i++) {
    const res = await login({ username: 'alice', password: PASS_A });
    assert.equal(res.status, 503);
  }
});

test('HTTP: 5回失敗でロックアウト（429）。ロック中は正しいパスワードでも拒否', async (t) => {
  const { login } = await startServer(t);
  for (let i = 0; i < 5; i++) {
    const res = await login({ username: 'alice', password: 'wrong-password' });
    assert.equal(res.status, 200);
  }
  const locked = await login({ username: 'alice', password: PASS_A });
  assert.equal(locked.status, 429);
  const lockedOtherCase = await login({ username: 'ALICE', password: PASS_A });
  assert.equal(lockedOtherCase.status, 429, 'ユーザー名の大文字小文字を変えても同じロック');
});

test('HTTP: 未設定時（従来）は store の users で認証する', async (t) => {
  const store = {
    async findUserByUsername(u) {
      return u === 'alice' ? { id: 1, username: 'alice', password_hash: HASH_A } : null;
    }
  };
  const { login } = await startServer(t, { store, usersProvider: null });
  assert.deepEqual((await login({ username: 'alice', password: PASS_A })).body, { success: true, username: 'alice' });
  assert.equal((await login({ username: 'alice', password: 'wrong-password' })).body.success, false);
});

test('HTTP: 従来モードで DB エラーなら 500（詳細は応答に出さない）', async (t) => {
  const store = { async findUserByUsername() { const e = new Error('connect ECONNREFUSED 127.0.0.1:5432'); e.code = 'ECONNREFUSED'; throw e; } };
  const { login } = await startServer(t, { store, usersProvider: null });
  const res = await login({ username: 'alice', password: PASS_A });
  assert.equal(res.status, 500);
  assert.ok(!JSON.stringify(res.body).includes('ECONNREFUSED'));
});
