'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');

const { Authenticator, AuthUnavailableError, MAX_PASSWORD_LENGTH } = require('../lib/authenticator');
const { UsersSecretProvider } = require('../lib/users-secret');
const { makeHash, usersJson, mockClient, awsError, fakeClock, silentLogger } = require('../test-support/helpers');

const PASS_A = 'alice-test-pass';
const PASS_B = 'bob-test-pass';
const HASH_A = makeHash(PASS_A);
const HASH_B = makeHash(PASS_B);

/** A store that fails the test if the secret mode touches the DB users table. */
function forbiddenStore() {
  const fail = (name) => () => { throw new Error(`store.${name} must not be called in secret mode`); };
  return {
    findUserByUsername: fail('findUserByUsername'),
    createUser: fail('createUser'),
    updatePassword: fail('updatePassword'),
    countUsers: fail('countUsers')
  };
}

function setup(responses, opts = {}) {
  const clock = fakeClock();
  const client = mockClient(responses);
  const usersProvider = new UsersSecretProvider({ secretId: 'test/users', region: 'ap-northeast-1', client, now: clock.now });
  const logger = silentLogger();
  const auth = new Authenticator({ store: opts.store || forbiddenStore(), usersProvider, logger });
  return { auth, client, clock, logger, usersProvider };
}

/** Count bcrypt comparisons (store.js calls bcrypt.compare through the module object). */
function countCompares(t) {
  const original = bcrypt.compare;
  const calls = [];
  bcrypt.compare = (password, hash) => { calls.push(hash); return original(password, hash); };
  t.after(() => { bcrypt.compare = original; });
  return calls;
}

test('secret: 正しいユーザー名とパスワードでログインできる（DB は使わない）', async () => {
  const { auth } = setup([usersJson({ alice: { passwordHash: HASH_A, email: 'alice@example.com', role: 'admin' } })]);
  const user = await auth.authenticate('alice', PASS_A);
  assert.deepEqual(user, { id: 'alice', username: 'alice', email: 'alice@example.com', role: 'admin', password_hash: HASH_A });
  assert.ok(auth.usesExternalUsers);
});

test('secret: パスワード誤りは null', async () => {
  const { auth } = setup([usersJson({ alice: { passwordHash: HASH_A } })]);
  assert.equal(await auth.authenticate('alice', 'wrong-password'), null);
  assert.equal(await auth.authenticate('alice', PASS_B), null);
});

test('secret: ユーザー名は完全一致（大文字小文字・前後空白を区別）', async () => {
  const { auth } = setup([usersJson({ alice: { passwordHash: HASH_A } })]);
  assert.equal(await auth.authenticate('Alice', PASS_A), null);
  assert.equal(await auth.authenticate('alice ', PASS_A), null);
});

test('secret: 未知のユーザーでも bcrypt 比較を1回以上行う（ユーザー列挙・タイミング差対策）', async (t) => {
  const { auth } = setup([usersJson({ alice: { passwordHash: HASH_A } })]);
  const calls = countCompares(t);
  assert.equal(await auth.authenticate('nobody', PASS_A), null);
  assert.ok(calls.length >= 1, 'ダミーハッシュとの比較が行われる');
  assert.ok(!calls.includes(HASH_A), '他人のハッシュとは比較しない');
});

test('secret: 未知ユーザーと誤パスワードで bcrypt の回数が同じ', async (t) => {
  const { auth, clock } = setup([usersJson({ alice: { passwordHash: HASH_A } })]);
  const calls = countCompares(t);
  await auth.authenticate('alice', 'wrong-password');
  const forWrongPassword = calls.length;
  calls.length = 0;
  clock.advance(60_000);   // 強制リフレッシュの間隔制限を同条件にする
  await auth.authenticate('nobody', 'wrong-password');
  assert.equal(calls.length, forWrongPassword);
});

test('secret: シークレット取得失敗時はログイン拒否（AuthUnavailableError）し、DB へフォールバックしない', async () => {
  const { auth } = setup([awsError('AccessDeniedException')]);
  await assert.rejects(auth.authenticate('alice', PASS_A), AuthUnavailableError);
  // forbiddenStore が呼ばれていれば上で別のエラーになる
});

test('secret: ログイン失敗時に1回だけ強制リフレッシュし、追加されたユーザーを即時反映する', async () => {
  const { auth, client } = setup([
    usersJson({ alice: { passwordHash: HASH_A } }),
    usersJson({ alice: { passwordHash: HASH_A }, bob: { passwordHash: HASH_B } })
  ]);
  await auth.warmUp();
  assert.equal(client.calls.length, 1);
  const bob = await auth.authenticate('bob', PASS_B);
  assert.equal(bob && bob.username, 'bob');
  assert.equal(client.calls.length, 2, '失敗→再取得は1回だけ');
});

test('secret: パスワード変更も失敗時の再取得で反映される', async () => {
  const NEW_PASS = 'alice-new-pass';
  const { auth } = setup([
    usersJson({ alice: { passwordHash: HASH_A } }),
    usersJson({ alice: { passwordHash: makeHash(NEW_PASS) } })
  ]);
  await auth.warmUp();
  assert.ok(await auth.authenticate('alice', NEW_PASS));
});

test('secret: 失敗が続いても強制リフレッシュは間隔制限内で1回まで', async () => {
  const { auth, client, clock } = setup([usersJson({ alice: { passwordHash: HASH_A } })]);
  await auth.warmUp();
  for (let i = 0; i < 5; i++) {
    assert.equal(await auth.authenticate(`nobody${i}`, 'wrong-password'), null);
    clock.advance(1000);
  }
  assert.equal(client.calls.length, 2, '起動時1回 + 強制1回のみ');
});

test('secret: 失敗後の再取得がエラーでも、ログイン失敗として扱う（500 にしない）', async () => {
  const { auth, logger } = setup([usersJson({ alice: { passwordHash: HASH_A } }), awsError('ThrottlingException')]);
  await auth.warmUp();
  assert.equal(await auth.authenticate('alice', 'wrong-password'), null);
  assert.ok(logger.lines.some((l) => /再取得に失敗/.test(l)));
  // 既存キャッシュで正しいログインは引き続き可能
  assert.ok(await auth.authenticate('alice', PASS_A));
});

test('secret: 空・型違い・長すぎるパスワードは照合せず null', async (t) => {
  const { auth } = setup([usersJson({ alice: { passwordHash: HASH_A } })]);
  const calls = countCompares(t);
  assert.equal(await auth.authenticate('alice', ''), null);
  assert.equal(await auth.authenticate('alice', 12345678), null);
  assert.equal(await auth.authenticate('alice', { $ne: '' }), null);
  assert.equal(await auth.authenticate('alice', 'x'.repeat(MAX_PASSWORD_LENGTH + 1)), null);
  assert.equal(calls.length, 0);
});

test('warmUp: 取得失敗はログに出して null（起動は継続、ログインは拒否）', async () => {
  const marker = 'WarmupSecretMarker_42';
  const { auth, logger } = setup([awsError('CredentialsProviderError', marker)]);
  assert.equal(await auth.warmUp(), null);
  assert.ok(logger.lines.some((l) => /ログインを拒否します/.test(l)));
  assert.ok(!logger.lines.join('\n').includes(marker));
});

test('warmUp: ユーザー0件なら警告', async () => {
  const { auth, logger } = setup(['{"users":{}}']);
  assert.equal(await auth.warmUp(), 0);
  assert.ok(logger.lines.some((l) => /1件もありません/.test(l)));
});

// ---------- 未設定時（従来動作） ----------

function legacyStore(rows) {
  const calls = [];
  return {
    calls,
    async findUserByUsername(username) {
      calls.push(username);
      return rows.find((r) => r.username === username) || null;
    }
  };
}

test('legacy: USERS_SECRET_* 未設定なら従来どおり store の users で認証する', async () => {
  const store = legacyStore([{ id: 7, username: 'alice', email: 'a@example.com', role: 'admin', password_hash: HASH_A }]);
  const auth = new Authenticator({ store, usersProvider: null, logger: silentLogger() });
  assert.equal(auth.usesExternalUsers, false);
  assert.match(auth.describe(), /users テーブル/);
  assert.equal(await auth.warmUp(), null);
  const user = await auth.authenticate('alice', PASS_A);
  assert.equal(user.id, 7);
  assert.equal(await auth.authenticate('alice', 'wrong-password'), null);
  assert.deepEqual(store.calls, ['alice', 'alice']);
});

test('legacy: 未知ユーザーでもダミーハッシュで bcrypt 比較する', async (t) => {
  const auth = new Authenticator({ store: legacyStore([]), usersProvider: null });
  const calls = countCompares(t);
  assert.equal(await auth.authenticate('nobody', PASS_A), null);
  assert.equal(calls.length, 1);
});

test('legacy: password_hash が NULL の行（シークレット運用に移行済みの DB）ではログインできない', async () => {
  const store = legacyStore([{ id: 1, username: 'alice', password_hash: null }]);
  const auth = new Authenticator({ store, usersProvider: null });
  assert.equal(await auth.authenticate('alice', PASS_A), null);
});
