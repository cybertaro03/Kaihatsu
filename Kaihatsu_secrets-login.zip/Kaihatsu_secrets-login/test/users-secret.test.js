'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const {
  UsersSecretProvider,
  UsersFileProvider,
  UsersSecretError,
  resolveUsersSourceConfig,
  createUsersProvider,
  parseUsersSecret
} = require('../lib/users-secret');
const { makeHash, usersJson, mockClient, awsError, fakeClock, silentLogger } = require('../test-support/helpers');

const SECRET_ID = 'test/wg-system/users';
const REGION = 'ap-northeast-1';
const HASH_A = makeHash('alice-test-pass');

function provider(responses, extra = {}) {
  const clock = extra.clock || fakeClock();
  const client = mockClient(responses);
  const p = new UsersSecretProvider({ secretId: SECRET_ID, region: REGION, client, now: clock.now, ...extra.opts });
  return { p, client, clock };
}

// ---------- 設定 ----------

test('config: 未設定なら従来の DB モード', () => {
  assert.deepEqual(resolveUsersSourceConfig({}), { mode: 'db' });
  assert.deepEqual(resolveUsersSourceConfig({ USERS_SECRET_ID: '  ' }), { mode: 'db' });
});

test('config: USERS_SECRET_ID + AWS_REGION で Secrets Manager モード', () => {
  assert.deepEqual(
    resolveUsersSourceConfig({ USERS_SECRET_ID: SECRET_ID, AWS_REGION: REGION }),
    { mode: 'secretsManager', secretId: SECRET_ID, region: REGION }
  );
  assert.equal(resolveUsersSourceConfig({ USERS_SECRET_ID: SECRET_ID, AWS_DEFAULT_REGION: REGION }).region, REGION);
});

test('config: USERS_SECRET_ID だけで AWS_REGION が無いとエラー', () => {
  assert.throws(() => resolveUsersSourceConfig({ USERS_SECRET_ID: SECRET_ID }), UsersSecretError);
});

test('config: USERS_SECRET_ID と USERS_SECRET_FILE の同時指定はエラー', () => {
  assert.throws(
    () => resolveUsersSourceConfig({ USERS_SECRET_ID: SECRET_ID, AWS_REGION: REGION, USERS_SECRET_FILE: '/tmp/x.json' }),
    /両方設定/
  );
});

test('config: USERS_SECRET_FILE のみならファイルモード', () => {
  assert.deepEqual(resolveUsersSourceConfig({ USERS_SECRET_FILE: '/etc/wg/users.json' }), { mode: 'file', filePath: '/etc/wg/users.json' });
});

test('createUsersProvider: DB モードでは null', () => {
  assert.equal(createUsersProvider({ mode: 'db' }), null);
});

// ---------- 解析 ----------

test('parse: 正しい形式を Map にする（role 省略時は member、email 省略時は空）', () => {
  const users = parseUsersSecret(usersJson({
    alice: { passwordHash: HASH_A, email: 'alice@example.com', role: 'admin' },
    bob: { passwordHash: HASH_A }
  }), 'label');
  assert.equal(users.size, 2);
  assert.deepEqual({ ...users.get('alice') }, { username: 'alice', email: 'alice@example.com', role: 'admin', passwordHash: HASH_A });
  assert.equal(users.get('bob').role, 'member');
  assert.equal(users.get('bob').email, '');
  assert.ok(Object.isFrozen(users.get('alice')));
});

test('parse: users が空でもエラーにはしない（誰もログインできないだけ）', () => {
  assert.equal(parseUsersSecret('{"users":{}}', 'label').size, 0);
});

test('parse: 平文パスワードや不正なハッシュは全体を拒否する（フェイルクローズ）', () => {
  const marker = 'PlainTextPasswordMarker123';
  for (const bad of [marker, '', '$2a$12$short', HASH_A + 'x', 123, null]) {
    assert.throws(
      () => parseUsersSecret(usersJson({ ok: { passwordHash: HASH_A }, ng: { passwordHash: bad } }), 'label'),
      (err) => {
        assert.ok(err instanceof UsersSecretError);
        assert.match(err.message, /2 番目のユーザー/);
        assert.ok(!err.message.includes(marker), '値をメッセージに含めない');
        return true;
      }
    );
  }
});

test('parse: 形式違い（JSON でない / users 無し / 配列 / 不正なユーザー名・email）を拒否', () => {
  assert.throws(() => parseUsersSecret('not json', 'L'), /JSON として解析できません/);
  assert.throws(() => parseUsersSecret('[]', 'L'), /JSON オブジェクトではありません/);
  assert.throws(() => parseUsersSecret('{"username":"x","password":"y"}', 'L'), /"users" オブジェクトがありません/);
  assert.throws(() => parseUsersSecret('{"users":[]}', 'L'), /"users" オブジェクトがありません/);
  assert.throws(() => parseUsersSecret(usersJson({ ' alice': { passwordHash: HASH_A } }), 'L'), /ユーザー名が不正/);
  assert.throws(() => parseUsersSecret(usersJson({ 'a\u0000b': { passwordHash: HASH_A } }), 'L'), /ユーザー名が不正/);
  assert.throws(() => parseUsersSecret(usersJson({ ['x'.repeat(81)]: { passwordHash: HASH_A } }), 'L'), /ユーザー名が不正/);
  assert.throws(() => parseUsersSecret(usersJson({ a: 'hash' }), 'L'), /オブジェクトではありません/);
  assert.throws(() => parseUsersSecret(usersJson({ a: { passwordHash: HASH_A, email: 5 } }), 'L'), /email が不正/);
});

test('parse: JSON 解析エラーのメッセージに内容の断片を含めない', () => {
  const marker = 'SuperSecretValue_ABC';
  assert.throws(
    () => parseUsersSecret(`{"users":{"a":{"passwordHash":"${marker}"`, 'L'),
    (err) => {
      assert.ok(!err.message.includes(marker));
      assert.equal(err.cause, undefined, 'cause も付けない（SyntaxError に断片が入るため）');
      return true;
    }
  );
});

test('parse: __proto__ という名前のユーザーでもプロトタイプ汚染しない', () => {
  const users = parseUsersSecret(`{"users":{"__proto__":{"passwordHash":"${HASH_A}"}}}`, 'L');
  assert.equal(users.get('__proto__').username, '__proto__');
  assert.equal({}.passwordHash, undefined);
});

// ---------- Secrets Manager プロバイダ ----------

test('provider: 起動時に1回取得し、以降はキャッシュを返す', async () => {
  const { p, client } = provider([usersJson({ alice: { passwordHash: HASH_A } })]);
  const a = await p.get();
  const b = await p.get();
  assert.equal(a, b);
  assert.equal(client.calls.length, 1);
  assert.equal(client.calls[0].input.SecretId, SECRET_ID);
  assert.ok(client.calls[0].options.abortSignal, 'タイムアウト用の AbortSignal を渡す');
});

test('provider: 同時の呼び出しは1回の取得に束ねる', async () => {
  const { p, client } = provider([usersJson({ alice: { passwordHash: HASH_A } })]);
  const [a, b, c] = await Promise.all([p.get(), p.get(), p.get({ forceRefresh: true })]);
  assert.equal(a, b);
  assert.equal(b, c);
  assert.equal(client.calls.length, 1);
});

test('provider: 強制リフレッシュは間隔制限付き（連続した強制は minRefreshInterval 内なら抑止）', async () => {
  const { p, client, clock } = provider([usersJson({ alice: { passwordHash: HASH_A } })]);
  await p.get();
  await p.get({ forceRefresh: true });          // 起動後最初の強制は取りに行く
  assert.equal(client.calls.length, 2);
  clock.advance(5_000);
  await p.get({ forceRefresh: true });          // 30 秒以内 → キャッシュ
  await p.get({ forceRefresh: true });
  assert.equal(client.calls.length, 2);
  clock.advance(30_000);
  await p.get({ forceRefresh: true });          // 間隔を空ければ再取得
  assert.equal(client.calls.length, 3);
});

test('provider: キャッシュは maxAge（既定5分）を過ぎたら次の get で取り直す（削除ユーザーの反映）', async () => {
  const { p, client, clock } = provider([
    usersJson({ alice: { passwordHash: HASH_A }, bob: { passwordHash: HASH_A } }),
    usersJson({ alice: { passwordHash: HASH_A } })
  ]);
  assert.ok((await p.get()).has('bob'));
  clock.advance(4 * 60 * 1000);
  assert.ok((await p.get()).has('bob'));
  assert.equal(client.calls.length, 1);
  clock.advance(60 * 1000);
  assert.ok(!(await p.get()).has('bob'));
  assert.equal(client.calls.length, 2);
});

test('provider: 取得失敗はエラー（キャッシュ無し）。失敗直後は再試行せずエラーを返す', async () => {
  const { p, client, clock } = provider([awsError('AccessDeniedException'), usersJson({ alice: { passwordHash: HASH_A } })]);
  await assert.rejects(p.get(), (err) => err instanceof UsersSecretError && /権限がありません/.test(err.message));
  await assert.rejects(p.get(), /再試行しません/);
  assert.equal(client.calls.length, 1, '失敗直後に Secrets Manager を連打しない');
  clock.advance(10_000);
  assert.ok((await p.get()).has('alice'));
  assert.equal(client.calls.length, 2);
});

test('provider: maxAge 切れ後の再取得に失敗したら古いキャッシュは使わない（フェイルクローズ）', async () => {
  const { p, clock } = provider([usersJson({ alice: { passwordHash: HASH_A } }), awsError('TimeoutError')]);
  await p.get();
  clock.advance(5 * 60 * 1000 + 1);
  await assert.rejects(p.get(), UsersSecretError);
});

test('provider: 有効なキャッシュがある状態で強制リフレッシュが失敗しても、キャッシュは使い続ける', async () => {
  const { p, clock } = provider([usersJson({ alice: { passwordHash: HASH_A } }), awsError('ThrottlingException')]);
  const first = await p.get();
  await assert.rejects(p.get({ forceRefresh: true }), UsersSecretError);
  clock.advance(1000);
  assert.equal(await p.get(), first);
  assert.equal(await p.get({ forceRefresh: true }), first);
});

test('provider: エラーメッセージ・cause に秘密値や SDK のメッセージを含めない', async () => {
  const marker = 'LeakedSecretMarker_9f8e7d';
  // 1) SDK エラーのメッセージに値が入っていたとしても出さない
  {
    const { p } = provider([awsError('SomeServiceError', `failure while reading ${marker}`)]);
    await assert.rejects(p.get(), (err) => {
      const dump = `${err.message} ${err.stack} ${err.cause && err.cause.message} ${JSON.stringify(err)}`;
      assert.ok(!dump.includes(marker), dump);
      assert.match(err.message, new RegExp(SECRET_ID.replace(/\//g, '\\/')));
      return true;
    });
  }
  // 2) シークレットの値が壊れていても値の断片を出さない
  {
    const { p } = provider([`{"users":{"alice":{"passwordHash":"${marker}"}}}`]);
    await assert.rejects(p.get(), (err) => !err.message.includes(marker) && !String(err.stack).includes(marker));
  }
  {
    const { p } = provider([`{"users":{"alice":{"passwordHash":"${marker}`]);
    await assert.rejects(p.get(), (err) => !err.message.includes(marker) && !String(err.stack).includes(marker));
  }
});

test('provider: ResourceNotFound の案内は USERS_SECRET_ID を指す', async () => {
  const { p } = provider([awsError('ResourceNotFoundException')]);
  await assert.rejects(p.get(), (err) => /USERS_SECRET_ID/.test(err.message) && !/DB_SECRET_ID/.test(err.message));
});

test('provider: SecretString が無い（バイナリ）場合はエラー', async () => {
  const { p } = provider([() => ({ SecretBinary: new Uint8Array([1, 2, 3]) })]);
  await assert.rejects(p.get(), /SecretString がありません/);
});

test('provider: secretId / region が無いと生成時にエラー', () => {
  assert.throws(() => new UsersSecretProvider({ region: REGION }), /USERS_SECRET_ID/);
  assert.throws(() => new UsersSecretProvider({ secretId: SECRET_ID }), /AWS_REGION/);
});

// ---------- ファイルプロバイダ（暫定） ----------

function tempFile(content) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wg-users-'));
  const file = path.join(dir, 'users.json');
  fs.writeFileSync(file, content, { mode: 0o600 });
  return file;
}

test('file provider: 読み込み、内容が変わらなければ再読込しない、変われば反映', async () => {
  const file = tempFile(usersJson({ alice: { passwordHash: HASH_A } }));
  const p = new UsersFileProvider({ filePath: file, logger: silentLogger() });
  const a = await p.get();
  assert.equal(await p.get(), a);
  assert.equal(p.fetchCount, 1);
  fs.writeFileSync(file, usersJson({ alice: { passwordHash: HASH_A }, bob: { passwordHash: HASH_A } }));
  const future = new Date(Date.now() + 5000);
  fs.utimesSync(file, future, future);
  assert.ok((await p.get()).has('bob'));
  assert.match(p.describe(), /暫定/);
});

test('file provider: ファイルが無い・壊れている場合はエラー（内容は出さない）', async () => {
  const missing = new UsersFileProvider({ filePath: path.join(os.tmpdir(), 'wg-no-such-file.json') });
  await assert.rejects(missing.get(), /ENOENT/);
  const marker = 'FileSecretMarker_123';
  const broken = new UsersFileProvider({ filePath: tempFile(`{"users":{"a":"${marker}`), logger: silentLogger() });
  await assert.rejects(broken.get(), (err) => err instanceof UsersSecretError && !err.message.includes(marker));
});

test('file provider: 所有者以外が読める権限なら警告する（POSIX のみ）', async () => {
  const file = tempFile(usersJson({ alice: { passwordHash: HASH_A } }));
  const logger = silentLogger();
  const p = new UsersFileProvider({ filePath: file, logger, platform: 'linux' });
  // Windows では chmod が効かないため、stat の mode を差し替えて確認する
  p.warnIfReadableByOthers({ mode: 0o100644 });
  assert.equal(logger.lines.length, 1);
  assert.match(logger.lines[0], /chmod 600/);
  const quiet = silentLogger();
  new UsersFileProvider({ filePath: file, logger: quiet, platform: 'linux' }).warnIfReadableByOthers({ mode: 0o100600 });
  assert.equal(quiet.lines.length, 0);
});
