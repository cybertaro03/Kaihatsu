'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawnSync } = require('child_process');

const { run, describeStorage } = require('../scripts/user');
const { parseUsersSecret } = require('../lib/users-secret');
const { makeHash, usersJson, mockClient } = require('../test-support/helpers');

const SECRET_ENV = { USERS_SECRET_ID: 'test/users', AWS_REGION: 'ap-northeast-1' };
const HASH_A = makeHash('alice-test-pass');

function io(answers = []) {
  const out = [];
  const err = [];
  const queue = [...answers];
  return {
    out, err,
    deps: {
      out: (s) => out.push(String(s)),
      err: (s) => err.push(String(s)),
      prompt: { ask: async () => (queue.length ? queue.shift() : null), close() {} }
    }
  };
}

test('CLI: 保存先表示は postgres を PostgreSQL と表示する（旧 mysql 判定の修正）', () => {
  assert.equal(describeStorage('postgres'), 'PostgreSQL');
  assert.equal(describeStorage('file'), 'ファイル (data/store.json)');
});

test('CLI hash: 対話入力のパスワードから bcrypt ハッシュと貼り付け用 JSON 断片を出す', async () => {
  const pass = 'cli-test-pass-1';
  const x = io([pass, pass]);
  const code = await run(['hash', 'alice', 'alice@example.com', 'admin'], { env: SECRET_ENV, client: mockClient([]), ...x.deps });
  assert.equal(code, 0);
  const text = x.out.join('\n');
  assert.ok(!text.includes(pass), '平文パスワードは表示しない');
  const fragment = x.out.find((l) => l.startsWith('"alice": '));
  assert.ok(fragment, text);
  // 断片はそのまま "users" に入れられる形
  const users = parseUsersSecret(`{"users":{${fragment}}}`, 'fragment');
  const entry = users.get('alice');
  assert.equal(entry.email, 'alice@example.com');
  assert.equal(entry.role, 'admin');
  assert.ok(await bcrypt.compare(pass, entry.passwordHash));
});

test('CLI hash: 確認不一致・短すぎ・不正なユーザー名はエラー', async () => {
  let x = io(['cli-test-pass-1', 'different-pass']);
  assert.equal(await run(['hash', 'alice'], { env: SECRET_ENV, ...x.deps }), 1);
  assert.match(x.err.join('\n'), /一致しません/);

  x = io(['short', 'short']);
  assert.equal(await run(['hash', 'alice'], { env: SECRET_ENV, ...x.deps }), 1);
  assert.match(x.err.join('\n'), /8文字以上/);

  x = io(['cli-test-pass-1', 'cli-test-pass-1']);
  assert.equal(await run(['hash', ' bad name'], { env: SECRET_ENV, ...x.deps }), 1);
  assert.match(x.err.join('\n'), /ユーザー名が不正/);
});

test('CLI list: シークレットのユーザー名・メール・権限を表示し、ハッシュは表示しない', async () => {
  const client = mockClient([usersJson({ alice: { passwordHash: HASH_A, email: 'alice@example.com', role: 'admin' } })]);
  const x = io();
  assert.equal(await run(['list'], { env: SECRET_ENV, client, ...x.deps }), 0);
  const text = x.out.join('\n');
  assert.match(text, /alice/);
  assert.match(text, /alice@example\.com/);
  assert.match(text, /admin/);
  assert.ok(!text.includes(HASH_A));
  assert.ok(!text.includes('$2a$'));
});

test('CLI add/passwd/del: シークレットモードでは AWS コンソールでの編集を案内して終了（DB に書かない）', async () => {
  for (const cmd of [['add', 'bob', 'bob@example.com', 'bob-test-pass'], ['passwd', 'alice', 'new-test-pass'], ['del', 'alice']]) {
    const client = mockClient([]);
    const x = io();
    assert.equal(await run(cmd, { env: SECRET_ENV, client, ...x.deps }), 1);
    assert.match(x.err.join('\n'), /AWS コンソール.*test\/users/);
    assert.equal(client.calls.length, 0);
  }
});

test('CLI (子プロセス): パイプ入力で hash が動き、平文を表示しない', () => {
  const pass = 'cli-pipe-pass-1';
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wg-cli-'));
  const file = path.join(dir, 'users.json');
  fs.writeFileSync(file, usersJson({}), { mode: 0o600 });
  const res = spawnSync(process.execPath, [path.join(__dirname, '..', 'scripts', 'user.js'), 'hash', 'carol'], {
    input: `${pass}\n${pass}\n`,
    env: { ...process.env, USERS_SECRET_ID: '', USERS_SECRET_FILE: file, DB_SECRET_ID: '', DOTENV_CONFIG_PATH: path.join(dir, 'none.env') },
    cwd: dir,
    encoding: 'utf8',
    timeout: 30000
  });
  assert.equal(res.status, 0, res.stderr);
  assert.match(res.stdout, /"carol": \{"passwordHash":"\$2a\$12\$/);
  assert.ok(!res.stdout.includes(pass));
  assert.ok(!res.stderr.includes(pass));
});
