'use strict';

// Shared test fixtures. Hashes are generated at runtime from throwaway values;
// no real password / hash / user data is stored in the repository.

const bcrypt = require('bcryptjs');

// Low cost keeps the tests fast; the format check accepts cost 04-31.
const TEST_COST = 4;

function makeHash(password) {
  return bcrypt.hashSync(password, TEST_COST);
}

function usersJson(users) {
  return JSON.stringify({ users });
}

/** Mock Secrets Manager client: `responses` is a list of SecretString values or Error objects. */
function mockClient(responses) {
  const calls = [];
  const queue = [...responses];
  return {
    calls,
    async send(command, options) {
      calls.push({ input: command.input, options });
      const next = queue.length > 1 ? queue.shift() : queue[0];
      if (next instanceof Error) throw next;
      if (typeof next === 'function') return next();
      return { SecretString: next };
    }
  };
}

function awsError(name, message) {
  const err = new Error(message || name);
  err.name = name;
  err.$metadata = { httpStatusCode: 400 };
  return err;
}

function fakeClock(start = 1_000_000) {
  let t = start;
  return {
    now: () => t,
    advance: (ms) => { t += ms; }
  };
}

function silentLogger() {
  const lines = [];
  const push = (...args) => lines.push(args.map(String).join(' '));
  return { lines, log: push, warn: push, error: push, info: push };
}

module.exports = { makeHash, usersJson, mockClient, awsError, fakeClock, silentLogger, TEST_COST };
