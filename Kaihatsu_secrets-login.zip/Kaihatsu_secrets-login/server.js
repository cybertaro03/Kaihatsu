'use strict';

/**
 * WG管理システム サーバー
 *
 *  - index.html / socket.io クライアントの配信
 *  - index.html が参照している API の実装（/api/db-status, /api/login）
 *    ログインの照合先は USERS_SECRET_ID（Secrets Manager）> USERS_SECRET_FILE（暫定）> DB users テーブル
 *  - Socket.IO によるリアルタイム同期とデータ永続化
 *
 * index.html 側の作りに合わせてあり、HTML の変更は不要。
 */

require('dotenv').config();

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const { Store } = require('./store');
const { resolveUsersSourceConfig, createUsersProvider } = require('./lib/users-secret');
const { Authenticator } = require('./lib/authenticator');
const { createLoginHandler } = require('./lib/login-route');

const PORT = Number(process.env.PORT || 3000);
const MAX_PAYLOAD_MB = Number(process.env.MAX_PAYLOAD_MB || 25);

const store = new Store();
// USERS_SECRET_ID / USERS_SECRET_FILE: login users live outside the DB.
// A configuration error here (e.g. both set, missing AWS_REGION) stops startup.
const { usersSourceConfig, authenticator } = (() => {
  try {
    const config = resolveUsersSourceConfig(process.env);
    return { usersSourceConfig: config, authenticator: new Authenticator({ store, usersProvider: createUsersProvider(config) }) };
  } catch (err) {
    console.error(`[server] 起動に失敗しました: ${err.message}`);
    process.exit(1);
  }
})();
const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  maxHttpBufferSize: MAX_PAYLOAD_MB * 1024 * 1024
});

// ---------- ミドルウェア ----------

app.set('trust proxy', Number(process.env.TRUST_PROXY_HOPS || 0));
app.use(express.json({ limit: `${MAX_PAYLOAD_MB}mb` }));

app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'DENY');
  res.set('Referrer-Policy', 'same-origin');
  next();
});

app.use(express.static(__dirname, {
  index: 'index.html',
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) res.set('Cache-Control', 'no-store');
  }
}));

// ---------- API（index.html が呼んでいるもの）----------

// ログイン画面右上のバッジ表示に使われる
app.get('/api/db-status', (req, res) => {
  res.json({ connected: store.connected, storage: store.mode });
});

// 認証元は authenticator が決める（USERS_SECRET_ID / USERS_SECRET_FILE / DB）。
// レート制限（IP + ユーザー名で5回失敗→5分ロック）は lib/login-route.js に移動（挙動は従来どおり）
app.post('/api/login', createLoginHandler({ authenticator }));

// ---------- Socket.IO ----------

function onlineUsers() {
  return Array.from(io.sockets.sockets.values()).map(s => ({
    id: s.id,
    name: s.data.userName
  }));
}

io.on('connection', (socket) => {
  socket.data.userName = String(socket.handshake.query?.userName || '匿名').slice(0, 40);
  console.log(`[socket] 接続: ${socket.data.userName} (${socket.id})`);

  socket.emit('sync:full', store.getState());
  io.emit('users:online', onlineUsers());

  socket.on('sync:request', () => {
    socket.emit('sync:full', store.getState());
  });

  // 画面側の saveData() が投げる全体更新
  socket.on('data:update', async (data) => {
    try {
      const state = await store.replaceAll(data);
      socket.broadcast.emit('sync:full', state);
    } catch (err) {
      console.error('[socket] data:update 失敗:', err.message);
    }
  });

  // CSV 復元：全クライアントへ再配信する
  socket.on('data:import', async (data) => {
    try {
      const state = await store.replaceAll(data);
      io.emit('sync:full', state);
      socket.broadcast.emit('user:activity', {
        userName: socket.data.userName,
        action: 'バックアップからデータを復元しました'
      });
    } catch (err) {
      console.error('[socket] data:import 失敗:', err.message);
    }
  });

  socket.on('vision:update', async (vision) => {
    try {
      const saved = await store.saveVision(vision);
      socket.broadcast.emit('sync:vision', saved);
    } catch (err) {
      console.error('[socket] vision:update 失敗:', err.message);
    }
  });

  socket.on('item:update', async (item) => {
    try {
      if (!item || !item.id) return;
      const saved = await store.saveItem(item);
      socket.broadcast.emit('sync:item', saved);
    } catch (err) {
      console.error('[socket] item:update 失敗:', err.message);
    }
  });

  socket.on('item:delete', async (itemId) => {
    try {
      if (!itemId) return;
      await store.deleteItem(itemId);
      socket.broadcast.emit('sync:itemDelete', itemId);
    } catch (err) {
      console.error('[socket] item:delete 失敗:', err.message);
    }
  });

  socket.on('minutes:update', async (minute) => {
    try {
      if (!minute || !minute.id) return;
      const saved = await store.saveMinute(minute);
      socket.broadcast.emit('sync:minutes', saved);
    } catch (err) {
      console.error('[socket] minutes:update 失敗:', err.message);
    }
  });

  socket.on('minutes:delete', async (minuteId) => {
    try {
      if (!minuteId) return;
      await store.deleteMinute(minuteId);
      socket.broadcast.emit('sync:minutesDelete', minuteId);
    } catch (err) {
      console.error('[socket] minutes:delete 失敗:', err.message);
    }
  });

  socket.on('user:activity', (activity) => {
    socket.broadcast.emit('user:activity', {
      userName: socket.data.userName,
      action: String(activity?.action || '').slice(0, 120)
    });
  });

  socket.on('disconnect', () => {
    console.log(`[socket] 切断: ${socket.data.userName} (${socket.id})`);
    io.emit('users:online', onlineUsers());
  });
});

// ---------- 起動 ----------

/**
 * users テーブルが空のときだけ、初期管理者を1件だけ作成する。
 * 認証情報をソースコードに持たないため、値は .env から受け取る。
 * 未設定なら何も作らず、CLI での登録を案内する。
 */
async function createInitialUserIfEmpty() {
  if ((await store.countUsers()) > 0) return;

  const username = (process.env.INITIAL_ADMIN_USER || '').trim();
  const email = (process.env.INITIAL_ADMIN_EMAIL || '').trim();
  const password = process.env.INITIAL_ADMIN_PASSWORD || '';

  if (!username || !password) {
    console.warn('[auth] ユーザーが1件も登録されていないため、誰もログインできません。');
    console.warn('[auth] 次のコマンドで登録してください:');
    console.warn('[auth]   npm run user -- add <ユーザー名> <メールアドレス> <パスワード>');
    return;
  }

  if (password.length < 8) {
    console.warn('[auth] INITIAL_ADMIN_PASSWORD が短すぎます（8文字以上）。初期ユーザーを作成しませんでした。');
    return;
  }

  await store.createUser({ username, email: email || `${username}@example.invalid`, password });
  console.warn(`[auth] 初期ユーザー ${username} を登録しました（.env の INITIAL_ADMIN_* より）。`);
  console.warn('[auth] 登録後は .env から INITIAL_ADMIN_PASSWORD を削除してください。');
}

/**
 * USERS_SECRET_ID / USERS_SECRET_FILE モードでは DB の users テーブルを使わないため、
 * 初期ユーザーの自動作成は行わない（password_hash を DB に書かない）。
 */
function warnUnusedInitialAdmin() {
  if ((process.env.INITIAL_ADMIN_PASSWORD || '').trim() === '') return;
  console.warn('[auth] INITIAL_ADMIN_PASSWORD が設定されていますが、ログインユーザーは ' +
    `${authenticator.describe()} で管理しているため使用しません。.env から削除してください。`);
}

async function main() {
  await store.init();
  if (authenticator.usesExternalUsers) {
    warnUnusedInitialAdmin();
    if (usersSourceConfig.mode === 'file') {
      console.warn('[auth] USERS_SECRET_FILE は暫定設定です。IAM ロール付与後は USERS_SECRET_ID（Secrets Manager）に切り替えてください。');
    }
    const count = await authenticator.warmUp();
    if (count !== null) console.log(`[auth] ログインユーザー: ${authenticator.describe()}（${count} 件）`);
  } else {
    await createInitialUserIfEmpty();
    console.log(`[auth] ログインユーザー: ${authenticator.describe()}`);
  }

  server.listen(PORT, () => {
    console.log(`WG管理システムを起動しました → http://localhost:${PORT}`);
    console.log(`ストレージ: ${store.mode === 'postgres' ? 'PostgreSQL' : 'ファイル (data/store.json)'}`);
  });
}

async function shutdown(signal) {
  console.log(`\n[server] ${signal} を受信。終了します...`);
  io.close();
  server.close();
  try { await store.close(); } catch (e) { /* noop */ }
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

main().catch(err => {
  console.error('[server] 起動に失敗しました:', err);
  process.exit(1);
});
