# ログイン処理の Secrets Manager 化 — 変更点と反映手順

- 作成: 2026-10-16 テックリード
- 元: `C:\Users\allen\Desktop\Kaihatsu_original`（変更していない）
- 作業先: このフォルダ（ローカル git のブランチ `feature/secrets-login`。push はしていない）
- **実機（EC2）・実際の AWS には一切触れていない。** AWS 部分はモックの単体テストのみで検証済み。実機での動作は**未確認**。

> この文書の JSON・ハッシュ・ユーザー名・メールアドレス・アカウント ID はすべてダミーです。
> 実際のパスワード・ハッシュ・ユーザー情報をこの文書やチケット・チャットに書かないでください。

---

## 1. 何が変わるか（要約）

| 項目 | 変更前 | 変更後（`USERS_SECRET_ID` 設定時） |
|---|---|---|
| ログインの照合先 | DB の `users` テーブル（`password_hash`） | Secrets Manager のシークレット（bcrypt ハッシュのみ） |
| DB へのパスワードハッシュ書き込み | 初回起動時の `INITIAL_ADMIN_*`、CLI の add/passwd | **しない**（初期ユーザー自動作成も行わない） |
| シークレット取得失敗時 | — | **ログイン拒否（HTTP 503）**。DB 等へのフォールバックなし |
| 未知ユーザー | bcrypt 比較なし（応答が速い＝ユーザー有無が推測可能） | ダミーハッシュで bcrypt 比較（従来方式でも同様に改善） |
| レート制限 | IP+ユーザー名で5回失敗→5分ロック | 同じ（コードを `lib/login-route.js` に移動しただけ） |

`USERS_SECRET_ID` も `USERS_SECRET_FILE` も未設定なら、従来どおり DB の `users` テーブルで認証します（開発用）。

## 2. 変更ファイル一覧

| ファイル | 種別 | 内容 |
|---|---|---|
| `lib/users-secret.js` | 新規 | 設定判定（`resolveUsersSourceConfig`）、シークレット JSON の検証（`parseUsersSecret`）、Secrets Manager プロバイダ（`UsersSecretProvider`。既存 `DbSecretProvider` を継承）、暫定ファイルプロバイダ（`UsersFileProvider`） |
| `lib/authenticator.js` | 新規 | ログイン照合。シークレット／従来 DB の切り替え、ダミーハッシュ比較、失敗時1回の強制リフレッシュ、フェイルクローズ |
| `lib/login-route.js` | 新規 | `/api/login` ハンドラとレート制限（server.js から移動。挙動は同じ。取得失敗時の 503 を追加） |
| `server.js` | 変更 | 上記モジュールの組み込み。シークレットモードでは `createInitialUserIfEmpty()` を呼ばない。起動ログに認証元を表示。**ストレージ表示の `'mysql'` 判定バグを修正**（PostgreSQL 接続時も「ファイル」と表示されていた） |
| `scripts/user.js` | 変更 | `hash` サブコマンド追加（対話入力・非表示）。シークレットモードでは `list` はシークレットを表示、`add/passwd/del` は案内して終了（DB に書かない）。**保存先表示の `'mysql'` 判定バグを修正**。テスト用に `run()` を export |
| `db/schema.sql` | 変更 | MySQL 構文 → PostgreSQL 構文に書き換え（下記 §9） |
| `.env.example` | 変更 | `USERS_SECRET_ID` / `USERS_SECRET_FILE` を追加。CLI の説明を実際の引数に合わせて修正 |
| `README.md` | 変更 | 「1. ログイン」に本番方式を追記、ファイル構成表を更新（README の他の章は MySQL 時代の記述が残っている。今回は未修正） |
| `.gitignore` | 新規 | `.env` / `data/` / `node_modules/` / `users.json` 等（README に記載があるのに元フォルダに存在しなかった） |
| `test/*.test.js`, `test-support/helpers.js` | 新規 | 単体テスト 56 件（§10） |
| `lib/db-secret.js` | **変更なし** | 本番 EC2 に暫定パッチが入っているため、意図的に触っていない（§8） |

## 3. 動作仕様

### 3.1 認証元の決定（起動時）

| `USERS_SECRET_ID` | `USERS_SECRET_FILE` | 動作 |
|---|---|---|
| 設定 | 空 | Secrets Manager（`AWS_REGION` 必須。無ければ起動しない） |
| 空 | 設定 | 【暫定】JSON ファイル |
| 設定 | 設定 | **起動しない**（設定ミスとして停止） |
| 空 | 空 | 従来の DB `users` テーブル |

### 3.2 取得・キャッシュ（Secrets Manager）

- 起動時に1回取得してメモリに保持。起動時に失敗しても**サーバーは起動し、ログインだけ拒否**する（ログに理由。IAM ロール付与後は再起動なしで復旧する）。
- 同時に来たリクエストの取得は1回に束ねる。タイムアウト 5 秒（既存 `DbSecretProvider` と同じ）。
- キャッシュの有効期間 **5 分**。期限切れ後の最初のログインで取り直す（削除ユーザーを反映するため）。
- ログイン失敗時に**1回だけ**強制再取得して照合し直す（ユーザー追加・パスワード変更を即時反映）。強制再取得は **30 秒に1回まで**。
- 取得に失敗したら **10 秒間は再試行しない**（未認証のリクエストで Secrets Manager を連打させないため）。
- 有効期限内のキャッシュがあれば、強制再取得の失敗時もそのキャッシュで照合を続ける。期限切れ後に取得できない場合は**ログイン拒否**（古い一覧は使わない）。
- エラーメッセージにはシークレット名・リージョン・AWS のエラー名だけを出す。シークレットの値・JSON 断片・SDK のエラーメッセージは出さない。

参考: 想定される呼び出し回数は「5 分に1回 + 失敗ログイン時に最大 30 秒に1回」。攻撃的な失敗ログインが続いても最大約 2,900 回/日程度（料金の目安は AWS の最新価格で確認すること。未確認）。

### 3.3 照合

- ユーザー名は**完全一致**（大文字小文字を区別）。従来の DB 照合（`username = $1`）と同じ。
- 未知ユーザーでもダミーハッシュと bcrypt 比較を行う。応答メッセージは誤パスワードと同一。
- 1024 文字を超えるパスワード・文字列以外の値は照合せずに失敗扱い（25MB まで受け付ける JSON ボディで bcrypt に巨大文字列を渡さないため）。
- 応答: 成功 `200 {success:true, username}` / 失敗 `200 {success:false}` / ロック中 `429` / 取得不能 `503`（ロックアウトの回数には数えない） / その他 `500`。
- ログイン後のセッション扱いは変更なし（この版の server.js はサーバー側セッションを持たず、ブラウザの sessionStorage で判定している。§11 参照）。

### 3.4 シークレットの検証（1件でも不正なら全体を拒否＝ログイン不可）

- トップレベルに `users` オブジェクトが必須。
- ユーザー名: 1〜80 文字、前後の空白・制御文字不可。
- `passwordHash`: bcrypt 形式（`$2a$` / `$2b$` / `$2y$`、cost 04〜31）のみ。平文は弾く。
- `email`（任意、120 文字以内）、`role`（任意、20 文字以内。省略時 `member`）。

## 4. シークレット JSON 例（ダミー値）

```json
{
  "users": {
    "example-admin": {
      "passwordHash": "$2a$12$DUMMYDUMMYDUMMYDUMMYDUuDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYD",
      "email": "admin@example.invalid",
      "role": "admin"
    },
    "example-member": {
      "passwordHash": "$2a$12$DUMMYDUMMYDUMMYDUMMYDUuDUMMYDUMMYDUMMYDUMMYDUMMYDUMMYD",
      "email": "member@example.invalid",
      "role": "member"
    }
  }
}
```

（上の passwordHash はダミーで、**わざと bcrypt 形式になっていません**。そのまま貼るとサーバーが形式エラーとして拒否します。実際の値は §6 の手順で生成してください。）

- シークレット名の例: `prod/wg-system/users`（既存の DB 用 `prod/wg-system/db` とは**別のシークレット**にする。DB 接続情報とログイン情報の権限・更新頻度を分けるため）
- 種類: 「その他のシークレットのタイプ」→ **プレーンテキスト**タブに上記 JSON を貼る（キー/値タブだと入れ子にできないため）
- 暗号化キー: 既定の `aws/secretsmanager` で可。カスタマー管理キーを使う場合は §5 の `kms:Decrypt` も必要

## 5. IAM ポリシー例（EC2 のインスタンスロールに付与）

既存の DB シークレットに加えて、users シークレットの `GetSecretValue` だけを許可します。アカウント ID・リージョンはダミーです。

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadWgSystemSecrets",
      "Effect": "Allow",
      "Action": "secretsmanager:GetSecretValue",
      "Resource": [
        "arn:aws:secretsmanager:ap-northeast-1:111122223333:secret:prod/wg-system/db-??????",
        "arn:aws:secretsmanager:ap-northeast-1:111122223333:secret:prod/wg-system/users-??????"
      ]
    }
  ]
}
```

- 末尾の `-??????` は Secrets Manager が付けるランダムな 6 文字に一致させるため（`-*` だと `prod/wg-system/users-old` 等の別シークレットにも一致してしまう）。作成後に表示される ARN をそのまま書いてもよい。
- EC2 側には `PutSecretValue` / `UpdateSecret` 等の**書き込み権限は与えない**（ユーザー編集は管理者が AWS コンソールで行う）。
- カスタマー管理 KMS キーを使う場合のみ、そのキーへの `kms:Decrypt` を追加。
- 誰がシークレットを編集・閲覧できるか（管理者の IAM ユーザー/ロール）は別途絞ること。CloudTrail で `GetSecretValue` / `PutSecretValue` の記録が残る。

## 6. パスワードハッシュの生成手順

手元の PC（Node.js と `npm install` 済みのこのプロジェクト）で実行します。AWS への接続は不要です。

```bash
npm run user -- hash example-admin admin@example.invalid admin
```

1. `パスワード:` `パスワード（確認）:` と聞かれるので入力（画面には表示されない。8 文字以上・72 バイト以内）
2. bcrypt ハッシュと、`"example-admin": {"passwordHash":"$2a$12$...","email":"...","role":"admin"}` という JSON 断片が表示される
3. AWS コンソール → Secrets Manager → `prod/wg-system/users` → 「シークレットの値を取得する」→「編集」→ プレーンテキストで `users` の中に断片を追加（既存ユーザーとの間は `,`）→ 保存
4. 保存前に JSON として正しいか確認する（不正な JSON や平文パスワードが入っていると**全員ログインできなくなる**。サーバーのログに「n 番目のユーザー」と位置が出る）

注意:
- パスワードはコマンドの引数に書かない（シェル履歴・プロセス一覧に残るため。`hash` は対話入力のみ）
- ハッシュはパスワードそのものではないが、漏れると総当たりの材料になる。チャット・メール・チケットに貼らない
- AWS CLI で登録する場合も `--secret-string` に直接書くとシェル履歴に残る。コンソールでの編集を推奨

## 7. 本番 EC2 への反映手順（GitHub 経由・PM2）

前提: IAM ロールへの §5 の権限付与が済んでいること（済んでいない間は §7.3 の暫定方式）。以下は手順案であり、**実機では未検証**。

### 7.1 事前準備（手元）

1. このブランチの内容を GitHub のリポジトリに反映（push・PR・マージは担当者が実施。テックリードは push していない）
2. Secrets Manager に `prod/wg-system/users` を作成し、§6 でユーザーを登録（最低1人の管理者）
3. IAM ロールに §5 のポリシーを付与

### 7.2 EC2 での作業

```bash
# アプリのディレクトリへ（実際のパスは要確認）
cd <アプリのディレクトリ>

# 0. 現状の記録（ロールバック用）
git rev-parse HEAD > ~/wg-before-secrets-login.txt
git status --short            # lib/db-secret.js の暫定パッチ等、ローカル変更を確認（§8）
cp .env ~/.env.before-secrets-login && chmod 600 ~/.env.before-secrets-login

# 1. 取得の確認（IAM ロールで読めるか。値は表示しない）
aws secretsmanager describe-secret --secret-id prod/wg-system/users --region ap-northeast-1 --query Name
# ※ describe-secret には secretsmanager:DescribeSecret が必要。GetSecretValue のみ許可している場合は省略し、手順 4 のログで確認する

# 2. コード更新（依存は既存のみ。package.json に変更なし）
git pull
npm ci --omit=dev             # package-lock.json が無い場合は npm install --omit=dev

# 3. .env に追記（エディタで編集。値はシークレット名のみで秘密ではない）
#    USERS_SECRET_ID=prod/wg-system/users
#    AWS_REGION=ap-northeast-1          # 既に DB 用に設定済みならそのまま
#    USERS_SECRET_FILE=                 # 空のまま（設定すると起動しない）
#    INITIAL_ADMIN_PASSWORD があれば削除

# 4. 再起動とログ確認
pm2 restart <PM2 のアプリ名> --update-env
pm2 logs <PM2 のアプリ名> --lines 50 --nostream
#   期待: 「[auth] ログインユーザー: Secrets Manager (prod/wg-system/users, ap-northeast-1)（n 件）」
#   NG 例: 「ログイン用ユーザー情報を取得できません ... [AccessDeniedException]」→ §5 の権限を確認
```

5. ブラウザでログイン確認（正しいパスワードで成功、誤りで失敗、存在しないユーザーで同じ失敗メッセージ）
6. 新方式で安定稼働を確認したら、**DB に残っている既存のパスワードハッシュを削除する**（コードは読まなくなるが、行は自動では消えない。オーナー要望「DB に置きたくない」の完了条件）。
   ロールバックできなくなるため、実施時期はオーナー判断。例: `DELETE FROM users;`（または `UPDATE users SET password_hash = NULL;`。既存テーブルが `NOT NULL` の場合は先に `ALTER TABLE users ALTER COLUMN password_hash DROP NOT NULL;`）。DB のバックアップを取ってから行うこと。

### 7.3 IAM ロール付与前の暫定運用（USERS_SECRET_FILE）

```bash
sudo install -d -m 700 -o <アプリ実行ユーザー> /etc/wg-system
# §4 と同じ形式の JSON を作成（ハッシュのみ。§6 で生成）。リポジトリの外に置く
sudo -u <アプリ実行ユーザー> vi /etc/wg-system/users.json
chmod 600 /etc/wg-system/users.json
# .env: USERS_SECRET_FILE=/etc/wg-system/users.json（USERS_SECRET_ID は空）
pm2 restart <PM2 のアプリ名> --update-env
```

- ファイルを編集すると、次のログインから反映される（再起動不要）。
- 所有者以外が読める権限だと起動ログに警告が出る。
- IAM ロール付与後は `USERS_SECRET_ID` に切り替え、**ファイルを削除**する（`shred -u` 等）。

## 8. 本番 EC2 の暫定改造（lib/db-secret.js の DB_SECRET_FILE パッチ）との関係

- 当該パッチのコードはテックリードの手元に無く、**内容は未確認**。以下は「パッチが DB 接続情報をファイルから読む分岐を `lib/db-secret.js` に追加したもの」という前提での整理。
- 今回の改修は `lib/db-secret.js` を**変更していない**。そのため:
  - EC2 が git の作業ツリーで、パッチがコミットされていないローカル変更であれば、`git pull` はこのファイルで衝突しない（他のファイルのみ更新される）見込み。ただし EC2 の git 状態は未確認。§7.2 の `git status` で確認すること。
  - `UsersSecretProvider` は `DbSecretProvider` を継承しているが、取得処理（`get` / `fetch`）は上書きしており、DB 用のファイル読み込み分岐は通らない。
  - **ただし、パッチがコンストラクタを変更している場合（例: `DB_SECRET_FILE` があると `secretId` を要求しない・別のフィールドを初期化する等）は影響し得る**。反映前にパッチの差分を確認し、必要ならテックリードに共有してほしい。
- `DB_SECRET_FILE`（DB 接続情報）と `USERS_SECRET_FILE`（ログインユーザー）は**独立**。どちらも IAM ロール付与までの暫定措置で、付与後はそれぞれ `DB_SECRET_ID` / `USERS_SECRET_ID` に切り替えて削除する。
- 恒久対応としては、パッチを正式なコード（設定・テスト付き）として取り込むか廃止するかを決める必要がある（別タスク）。

## 9. db/schema.sql の変更（MySQL → PostgreSQL）

元の `db/schema.sql` は MySQL 構文のままで、`DB_AUTO_SCHEMA=true`（既定）で PostgreSQL に起動すると失敗する状態だった。`store.js` の SQL（`ON CONFLICT`、`$1`、`::jsonb`、`ORDER BY seq`）に合わせて書き換えた。

| 項目 | 変更内容 |
|---|---|
| `CREATE DATABASE` / `USE` | 削除（全体を1クエリで流すため。DB 作成は手動手順をコメントに記載） |
| 自動採番 | `AUTO_INCREMENT` → `GENERATED BY DEFAULT AS IDENTITY` |
| JSON | `JSON` → `JSONB` |
| 日時 | `TIMESTAMP` / `DATETIME` → `TIMESTAMPTZ`、`ON UPDATE CURRENT_TIMESTAMP` 削除（アプリ側で `now()`） |
| `items` / `minutes` | **`seq BIGINT GENERATED ALWAYS AS IDENTITY` を追加**（store.js が `ORDER BY seq` で読む）＋インデックス |
| `users.password_hash` | **`NOT NULL` → `NULL` 可**（シークレット運用では使わない） |
| `users` の一意制約 | `lower(username)` / `lower(email)` の一意インデックス（MySQL の大文字小文字非区別の照合順序に相当） |
| `vision.id` | `SMALLINT ... CHECK (id = 1)` |
| その他 | `ENGINE` / `CHARSET` 等の MySQL 固有句を削除、同時起動対策に `pg_advisory_xact_lock` |

- 内容は `プロジェクト/Kaihatsu/db/schema.sql`（別フォルダの改修版）とほぼ同じで、`password_hash` の NULL 可だけが異なる。
- すべて `IF NOT EXISTS` のため、**既存テーブルの列定義は変わらない**（既に `NOT NULL` で作られた `users` はそのまま。シークレット運用ではこの列を読み書きしないので動作上の問題はない）。
- **実際の PostgreSQL での実行は未検証**（手元に PostgreSQL が無い）。反映前にステージングか本番 DB のコピーで `psql -f db/schema.sql` を確認すること。

## 10. テスト

`npm test`（`node --test`）。ネットワーク・実 DB・実 AWS には触れない（Secrets Manager はモック client、HTTP は 127.0.0.1 のエフェメラルポート）。

| ファイル | 主な確認内容 |
|---|---|
| `test/users-secret.test.js` | 設定判定、JSON 検証（平文拒否・プロトタイプ汚染なし）、キャッシュ・同時取得の束ね・強制リフレッシュ間隔制限・5 分の有効期限・失敗後の再試行抑止・フェイルクローズ、エラーに秘密値/SDK メッセージを含めない、ファイルプロバイダ |
| `test/authenticator.test.js` | 正常ログイン、誤パスワード、未知ユーザーでも bcrypt 比較・回数が同じ、取得失敗で拒否し DB を呼ばない、失敗時1回の再取得で追加/変更を反映、連続失敗でも再取得は1回、未設定時の従来動作 |
| `test/login-route.test.js` | HTTP レベル: 成功応答にハッシュを含めない、誤パスワードと未知ユーザーの応答が同一、503 と内部情報非開示、503 はロックアウトに数えない、5 回失敗で 429、従来モード |
| `test/user-cli.test.js` | `hash` の出力が貼り付け可能な断片で平文を出さない、確認不一致等のエラー、`list` がハッシュを出さない、`add/passwd/del` が案内して DB に触らない、子プロセスでのパイプ入力、保存先表示の修正 |

実行結果（2026-10-16、Windows / Node.js v24.20.0）: tests 56 / pass 56 / fail 0。Node.js 18/20/22 では未実行。

## 11. ロールバック手順

```bash
cd <アプリのディレクトリ>
git checkout $(cat ~/wg-before-secrets-login.txt)    # またはデプロイ用ブランチを revert して pull
npm ci --omit=dev
# .env を戻す（USERS_SECRET_ID を削除）
cp ~/.env.before-secrets-login .env
pm2 restart <PM2 のアプリ名> --update-env
```

- コードを戻さずに **`.env` の `USERS_SECRET_ID` を空にして再起動するだけでも従来方式（DB の users）に戻る**（新コードの従来モード）。
- 従来方式に戻すと **DB の `users` テーブルで照合する**ため、§7.2 手順 6 で DB のハッシュを削除した後はそのままではログインできない。その場合は `npm run user -- add ...` で登録し直す必要がある。
- `db/schema.sql` の変更は `IF NOT EXISTS` のみで既存テーブルを変更しないため、DB 側のロールバック作業は不要。
- Secrets Manager のシークレットと IAM 権限は残しても動作に影響しない（不要になったら削除）。

## 12. 既知の制約・未対応（別タスク候補）

- **この版の server.js は Socket.IO 接続にログインを要求しない**（既存の問題。README §7 にも記載）。ログインの照合先を Secrets Manager にしても、ポートに到達できる人は画面を経由せずにデータを読み書きできる。IP 制限（nginx / セキュリティグループ）が実質の防御。`プロジェクト/Kaihatsu`（別フォルダの改修版）には HttpOnly Cookie のサーバー側セッション（`lib/sessions.js` を使う `app.js`）があるが、`Kaihatsu_original` の server.js には組み込まれていない。
- この版の server.js は `lib/listen-config.js` を使っておらず、`server.listen(PORT)` で全インターフェースに待ち受ける（既存の問題）。
- 従来方式の CLI（`add` / `passwd`）はパスワードを引数で受け取る（既存の仕様。シークレット方式の `hash` は対話入力）。
- パスワード変更後、旧パスワードでも最大 5 分（キャッシュ有効期間内）はログインできる。即時に無効化したい場合はサーバーを再起動する。
- ダミーハッシュのコストは 12。シークレットに異なるコストのハッシュを登録すると、未知ユーザーとの応答時間差がわずかに生じる（`hash` コマンドはコスト 12 で生成するため、これを使えば揃う）。
- `role` は保存・表示するだけで、権限による画面・操作の制御は行っていない（既存どおり）。
- 本番 EC2 で動いているコードが `Kaihatsu_original` と `プロジェクト/Kaihatsu` のどちらに近いかは**未確認**。後者に近い場合は、今回の変更を `app.js` 側に移植する必要がある。
