#!/usr/bin/env node
'use strict';

/**
 * ユーザー管理 CLI
 *
 * ■ USERS_SECRET_ID（Secrets Manager）/ USERS_SECRET_FILE（暫定）設定時
 *   ログインユーザーは DB ではなくシークレットで管理する。この CLI は DB に書き込まない。
 *     node scripts/user.js hash [ユーザー名] [メールアドレス] [権限]
 *         パスワードを対話入力（画面に表示しない）で受け、bcrypt ハッシュと
 *         シークレットに貼り付ける JSON 断片を表示する
 *     node scripts/user.js list
 *         シークレットのユーザー名・メール・権限を表示（ハッシュは表示しない）
 *     add / passwd / del
 *         AWS コンソールでシークレットを編集するよう案内して終了する
 *
 * ■ 未設定時（従来方式・開発用）: DB の users テーブル / data/store.json を操作する
 *     node scripts/user.js list
 *     node scripts/user.js add <ユーザー名> <メールアドレス> <パスワード>
 *     node scripts/user.js passwd <ユーザー名> <新しいパスワード>
 *     node scripts/user.js del <ユーザー名>
 *     node scripts/user.js hash [ユーザー名] [メールアドレス] [権限]   （シークレット登録の準備用）
 *
 * パスワードは bcrypt ハッシュとして扱い、平文は保存しない。
 */

require('dotenv').config();

const readline = require('readline');
const bcrypt = require('bcryptjs');

const { Store, validateNewPassword, BCRYPT_ROUNDS } = require('../store');
const {
  resolveUsersSourceConfig,
  createUsersProvider,
  isValidUsername,
  USERNAME_MAX_LENGTH,
  DEFAULT_ROLE
} = require('../lib/users-secret');

function usage(out = console.log) {
  out(`
使い方:
  node scripts/user.js hash [ユーザー名] [メールアドレス] [権限]   パスワードを対話入力し、bcrypt ハッシュを表示
  node scripts/user.js list

  （USERS_SECRET_ID / USERS_SECRET_FILE 未設定時のみ。DB の users テーブルを操作）
  node scripts/user.js add <ユーザー名> <メールアドレス> <パスワード>
  node scripts/user.js passwd <ユーザー名> <新しいパスワード>
  node scripts/user.js del <ユーザー名>
`.trim());
}

function describeStorage(mode) {
  return mode === 'postgres' ? 'PostgreSQL' : 'ファイル (data/store.json)';
}

// ---------- パスワードの対話入力 ----------

/**
 * Reads lines from stdin. On a TTY the typed characters are not echoed.
 * When stdin is a pipe (automation / tests) lines are read as-is.
 */
class PasswordPrompt {
  constructor({ input = process.stdin, output = process.stderr } = {}) {
    this.input = input;
    this.output = output;
    this.rl = null;
    this.lines = [];
    this.waiters = [];
    this.closed = false;
  }

  start() {
    if (this.rl) return;
    this.rl = readline.createInterface({ input: this.input, terminal: false });
    this.rl.on('line', (line) => {
      const waiter = this.waiters.shift();
      if (waiter) waiter.resolve(line);
      else this.lines.push(line);
    });
    this.rl.on('close', () => {
      this.closed = true;
      for (const w of this.waiters.splice(0)) w.resolve(null);
    });
  }

  async ask(question) {
    this.output.write(question);
    const isTty = Boolean(this.input.isTTY && this.input.setRawMode);
    const line = isTty ? await this.readHiddenTty() : await this.readLine();
    if (isTty) this.output.write('\n');
    return line;
  }

  readLine() {
    this.start();
    if (this.lines.length) return Promise.resolve(this.lines.shift());
    if (this.closed) return Promise.resolve(null);
    return new Promise((resolve) => this.waiters.push({ resolve }));
  }

  readHiddenTty() {
    const input = this.input;
    return new Promise((resolve) => {
      let value = '';
      const finish = (result) => {
        input.removeListener('data', onData);
        input.setRawMode(false);
        input.pause();
        resolve(result);
      };
      const onData = (chunk) => {
        for (const ch of String(chunk)) {
          if (ch === '\r' || ch === '\n') return finish(value);
          if (ch === '\u0003') { finish(null); process.exit(130); }   // Ctrl+C
          if (ch === '\u0004') return finish(value.length ? value : null); // Ctrl+D
          if (ch === '\u007f' || ch === '\b') { value = value.slice(0, -1); continue; }
          value += ch;
        }
        return undefined;
      };
      input.setRawMode(true);
      input.resume();
      input.setEncoding('utf8');
      input.on('data', onData);
    });
  }

  close() {
    if (this.rl) this.rl.close();
  }
}

// ---------- hash ----------

/**
 * @param {string[]} args  [username, email, role]
 * @param {object} io { prompt, out, err }
 * @returns {Promise<number>} exit code
 */
async function runHash(args, { prompt, out, err }) {
  const [username, email, role] = args;
  if (username !== undefined && !isValidUsername(username)) {
    err(`ユーザー名が不正です（1〜${USERNAME_MAX_LENGTH}文字、前後の空白・制御文字は不可）。`);
    return 1;
  }

  const password = await prompt.ask('パスワード: ');
  if (password === null) { err('入力が中断されました。'); return 1; }
  const problem = validateNewPassword(password);
  if (problem) { err(problem); return 1; }
  const confirm = await prompt.ask('パスワード（確認）: ');
  if (confirm !== password) { err('確認用のパスワードが一致しません。'); return 1; }

  const hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
  const entry = { passwordHash: hash, email: email || '', role: role || DEFAULT_ROLE };
  const name = username || '<ユーザー名>';

  out('');
  out('bcrypt ハッシュ:');
  out(hash);
  out('');
  out('シークレットの "users" の中に貼り付ける JSON 断片（既存ユーザーの後ろに , で区切って追加）:');
  out(`${JSON.stringify(name)}: ${JSON.stringify(entry)}`);
  out('');
  out('※ このハッシュはパスワードそのものではありませんが、漏れると総当たり攻撃の材料になります。');
  out('  チャット・メール・チケット等には貼らず、Secrets Manager の画面にだけ入力してください。');
  return 0;
}

// ---------- シークレットモード ----------

async function runSecretMode(command, args, { config, provider, prompt, out, err }) {
  out(`ログインユーザーの保存先: ${provider.describe()}\n`);

  switch (command) {
    case 'hash':
      return runHash(args, { prompt, out, err });

    case 'list': {
      const users = await provider.get();
      if (users.size === 0) {
        out('ユーザーが登録されていません。');
        return 0;
      }
      out('ユーザー名'.padEnd(20) + 'メールアドレス'.padEnd(32) + '権限');
      out('-'.repeat(64));
      for (const u of users.values()) {
        out(String(u.username).padEnd(20) + String(u.email || '').padEnd(32) + (u.role || ''));
      }
      return 0;
    }

    case 'add':
    case 'passwd':
    case 'del': {
      const where = config.mode === 'secretsManager'
        ? `AWS コンソールの Secrets Manager でシークレット「${config.secretId}」を編集してください。`
        : `USERS_SECRET_FILE（${config.filePath}）を編集してください（暫定運用）。`;
      err(`${command} はこのモードでは使えません（ユーザーは DB ではなくシークレットで管理しています）。`);
      err(where);
      err('パスワードのハッシュは「npm run user -- hash <ユーザー名> <メールアドレス> [権限]」で生成できます。');
      return 1;
    }

    default:
      usage(err);
      return 1;
  }
}

// ---------- 従来モード（DB users テーブル） ----------

async function runDbMode(command, args, { out, err }) {
  const store = new Store();
  await store.init();
  out(`保存先: ${describeStorage(store.mode)}\n`);

  try {
    switch (command) {
      case 'list': {
        const users = await store.listUsers();
        if (users.length === 0) {
          out('ユーザーが登録されていません。');
          break;
        }
        out('ユーザー名'.padEnd(20) + 'メールアドレス'.padEnd(32) + '権限');
        out('-'.repeat(64));
        for (const u of users) {
          out(String(u.username).padEnd(20) + String(u.email || '').padEnd(32) + (u.role || ''));
        }
        break;
      }

      case 'add': {
        const [username, email, password] = args;
        if (!username || !email || !password) { usage(err); return 1; }
        if (password.length < 8) {
          err('パスワードは8文字以上にしてください。');
          return 1;
        }
        if (await store.findUserByUsername(username)) {
          err(`ユーザー ${username} は既に存在します。パスワード変更は passwd を使ってください。`);
          return 1;
        }
        await store.createUser({ username, email, password });
        out(`ユーザー ${username} を登録しました。`);
        break;
      }

      case 'passwd': {
        const [username, password] = args;
        if (!username || !password) { usage(err); return 1; }
        if (password.length < 8) {
          err('パスワードは8文字以上にしてください。');
          return 1;
        }
        const user = await store.findUserByUsername(username);
        if (!user) {
          err(`ユーザー ${username} が見つかりません。`);
          return 1;
        }
        await store.updatePassword(user.id, password);
        out(`ユーザー ${username} のパスワードを更新しました。`);
        break;
      }

      case 'del': {
        const [username] = args;
        if (!username) { usage(err); return 1; }
        const user = await store.findUserByUsername(username);
        if (!user) {
          err(`ユーザー ${username} が見つかりません。`);
          return 1;
        }
        const remaining = (await store.listUsers()).length - 1;
        if (remaining <= 0) {
          err('最後のユーザーは削除できません（ログインできなくなるため）。');
          return 1;
        }
        await store.deleteUser(user.id);
        out(`ユーザー ${username} を削除しました。`);
        break;
      }

      default:
        usage(err);
        return 1;
    }
    return 0;
  } finally {
    await store.close();
  }
}

// ---------- エントリポイント ----------

/**
 * @param {string[]} argv  process.argv.slice(2)
 * @param {object} [deps]  { env, client, prompt, out, err } injected in tests
 */
async function run(argv, deps = {}) {
  const out = deps.out || ((s) => console.log(s));
  const err = deps.err || ((s) => console.error(s));
  const [command, ...args] = argv;

  if (!command || command === 'help' || command === '--help') {
    usage(out);
    return 0;
  }

  const config = resolveUsersSourceConfig(deps.env || process.env);
  const prompt = deps.prompt || new PasswordPrompt();
  try {
    if (config.mode !== 'db') {
      const provider = createUsersProvider(config, { client: deps.client });
      return await runSecretMode(command, args, { config, provider, prompt, out, err });
    }
    // hash は DB に触らないので、従来モードでも DB に接続せずに実行する
    if (command === 'hash') return await runHash(args, { prompt, out, err });
    return await runDbMode(command, args, { out, err });
  } finally {
    if (!deps.prompt) prompt.close();
  }
}

module.exports = { run, runHash, PasswordPrompt, describeStorage };

if (require.main === module) {
  run(process.argv.slice(2))
    .then(code => process.exit(code))
    .catch(e => {
      console.error('エラー:', e.message);
      process.exit(1);
    });
}
