#!/usr/bin/env node
'use strict';

/**
 * ユーザー管理 CLI（DB の users テーブルを操作する）
 *
 *   node scripts/user.js list
 *   node scripts/user.js add <ユーザー名> <メールアドレス> <パスワード>
 *   node scripts/user.js passwd <ユーザー名> <新しいパスワード>
 *   node scripts/user.js del <ユーザー名>
 *
 * .env の設定に従い、MySQL が使えれば MySQL、無ければ data/store.json を操作する。
 * パスワードは bcrypt ハッシュとして保存され、平文は保存されない。
 */

require('dotenv').config();

const { Store } = require('../store');

function usage() {
  console.log(`
使い方:
  node scripts/user.js list
  node scripts/user.js add <ユーザー名> <メールアドレス> <パスワード>
  node scripts/user.js passwd <ユーザー名> <新しいパスワード>
  node scripts/user.js del <ユーザー名>
`.trim());
}

async function main() {
  const [command, ...args] = process.argv.slice(2);

  if (!command || command === 'help' || command === '--help') {
    usage();
    return 0;
  }

  const store = new Store();
  await store.init();
  console.log(`保存先: ${store.mode === 'mysql' ? 'MySQL' : 'ファイル (data/store.json)'}\n`);

  try {
    switch (command) {
      case 'list': {
        const users = await store.listUsers();
        if (users.length === 0) {
          console.log('ユーザーが登録されていません。');
          break;
        }
        console.log('ユーザー名'.padEnd(20) + 'メールアドレス'.padEnd(32) + '権限');
        console.log('-'.repeat(64));
        for (const u of users) {
          console.log(String(u.username).padEnd(20) + String(u.email || '').padEnd(32) + (u.role || ''));
        }
        break;
      }

      case 'add': {
        const [username, email, password] = args;
        if (!username || !email || !password) { usage(); return 1; }
        if (password.length < 8) {
          console.error('パスワードは8文字以上にしてください。');
          return 1;
        }
        if (await store.findUserByUsername(username)) {
          console.error(`ユーザー ${username} は既に存在します。パスワード変更は passwd を使ってください。`);
          return 1;
        }
        await store.createUser({ username, email, password });
        console.log(`ユーザー ${username} を登録しました。`);
        break;
      }

      case 'passwd': {
        const [username, password] = args;
        if (!username || !password) { usage(); return 1; }
        if (password.length < 8) {
          console.error('パスワードは8文字以上にしてください。');
          return 1;
        }
        const user = await store.findUserByUsername(username);
        if (!user) {
          console.error(`ユーザー ${username} が見つかりません。`);
          return 1;
        }
        await store.updatePassword(user.id, password);
        console.log(`ユーザー ${username} のパスワードを更新しました。`);
        break;
      }

      case 'del': {
        const [username] = args;
        if (!username) { usage(); return 1; }
        const user = await store.findUserByUsername(username);
        if (!user) {
          console.error(`ユーザー ${username} が見つかりません。`);
          return 1;
        }
        const remaining = (await store.listUsers()).length - 1;
        if (remaining <= 0) {
          console.error('最後のユーザーは削除できません（ログインできなくなるため）。');
          return 1;
        }
        await store.deleteUser(user.id);
        console.log(`ユーザー ${username} を削除しました。`);
        break;
      }

      default:
        usage();
        return 1;
    }
    return 0;
  } finally {
    await store.close();
  }
}

main()
  .then(code => process.exit(code))
  .catch(err => {
    console.error('エラー:', err.message);
    process.exit(1);
  });
